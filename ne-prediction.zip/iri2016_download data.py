# -*- coding: utf-8 -*-
"""

@author: HSM
timestamp：range(1483200000,1577808000,7200)，间隔为2 hour
2017-1-1 00:00:00----2019-12-31 23:00:00
"""
import os
import datetime
import iri2016
import numpy as np
len_al=23   #altitude，(80,300,10)
len_la=37   #latitude，(-90,95,5)
len_lo=37   #longitude，(0,370,10)
len_time=13140 
timestamp0=1483200000
timestampend=1577808000
iri2016_data=np.zeros((len_time, len_al,len_la,len_lo),dtype='float32')
for timestamp in range(timestamp0,timestampend,7200):
    d = datetime.datetime.fromtimestamp(timestamp)
    str_time = d.strftime("%Y-%m-%dT%H")
    n_la=0
    for la in range(-90,95,5):
        n_lo=0
        for lo in range(0,370,10):
            iono = iri2016.IRI(str_time,(80,300,10),la,lo)
            data=np.array(iono.ne,dtype='float32')
            iri2016_data[n_time,:,n_la,n_lo]=data
            n_lo=n_lo+1
        n_la=n_la+1

np.save('D:/DATASET/ne_data/nedata17-19-2h.npy', iri2016_data)
print('Saved successfully!')

